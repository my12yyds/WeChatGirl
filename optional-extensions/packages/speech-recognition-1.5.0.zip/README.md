# 微信语音识别

版本：1.5.0 · 可选插件，按需安装

[返回插件目录](https://github.com/my12yyds/WeChatGirl/blob/main/docs/plugins/README.md)

## 适合做什么

把收到的微信语音转为文字，供当前聊天模型理解。

识别已授权好友和群聊的语音，再由当前聊天模型回复。可使用本机 SenseVoice、本机 Whisper 或外接识别 API。

## 第一次配置

1. 在能力目录导入该插件，或导入总包。
2. 选择支持音频的模型/API、协议与音频格式，使用配置页检测后授权聊天。
3. 在“插件与聊天”选择具体好友或群聊，不需要的范围保持关闭。
4. 保存并检查插件状态，先用简单请求验证；升级宿主接口后按提示完整重开DSH。

### 使用本机 SenseVoice

已安装本机组件时，选择「本机 SenseVoice（CPU）」并点击「检测配置」。测试会实际转写内置短句。随后启用插件，授予语音读取权限，按聊天授权。WAV 在本机处理，DSH 只接收转写文字。

手动准备时，使用与宿主相同版本的 Windows x64 Python。将 sherpa-onnx 1.12.34 安装到工作区的 `state/asr/sensevoice/site`，将官方量化模型包的 `model.int8.onnx` 和 `tokens.txt` 放到 `state/asr/sensevoice/`。模型和依赖单独准备。 [SenseVoice 模型下载与说明](https://k2-fsa.github.io/sherpa/onnx/sense-voice/pretrained.html)

### 使用本机 Whisper

1. 准备 Windows 版 whisper.cpp 与支持中文的多语种模型，例如 `ggml-base.bin`。在模型所在目录启动服务：

   ```powershell
   .\whisper-server.exe -m .\ggml-base.bin --host 127.0.0.1 --port 8080 -l zh
   ```

2. 在插件设置将“API 协议”设为“本机 Whisper 模型”。服务地址可留空使用 `http://127.0.0.1:8080/inference`。在这里无需填写模型 ID 或密钥，模型由服务器启动参数选择。
3. 点击“检测配置”，确认短句转写和 WAV 转换均通过。启用插件、授予语音读取权限，并为需要的好友或群聊勾选该插件。

本机服务收到 WAV，DSH 在聊天流程中收到转写文字。外接 API 模式会按配置把音频发送给该服务。当前 DSH 桥接负责分配转写任务和聊天回复，未接入 DSH 模型的原始音频输入。[whisper.cpp 服务说明](https://github.com/ggml-org/whisper.cpp/tree/master/examples/server)

## 使用例子

在授权聊天发送一条短语音，检查转写与回复。

## 权限与数据

- 读取当前微信语音。外接模式向所选 API 上传音频，本机模式仅请求回环服务。

关闭插件停止后续调用，已有本机数据保留。总包导入不会启用插件、放宽聊天授权或覆盖已安装插件。

## 配置选项

| 配置 | 默认值 | 范围或选择 | 说明 |
| --- | --- | --- | --- |
| API 协议 | "auto" | auto / local-sensevoice / local-whisper / openai-transcriptions / openai-chat / chat-audio-data-url / anthropic-messages / custom | 按协议处理服务地址、鉴权和请求；自定义请求保留高级模板。 |
| API 服务地址 | "" | 最多2048字符 | 标准协议可填写基础地址（含所需版本路径）或完整识别地址，保留网关路径前缀；自定义请求填写完整 POST 地址。 |
| API Key | 留空，保存后加密 | 最多4096字符 | 按页面提示设置；保存后用于之后的新任务。 |
| 密钥请求头名称 | "Authorization" | 最多100字符 | 按页面提示设置；保存后用于之后的新任务。 |
| 密钥前缀（保留末尾空格） | "Bearer " | 最多100字符 | 按页面提示设置；保存后用于之后的新任务。 |
| 额外请求头（JSON） | 留空，保存后加密 | 最多16000字符 | 可填写自定义鉴权头；界面隐藏已保存值。 |
| 请求格式 | "multipart" | multipart / json | 按页面提示设置；保存后用于之后的新任务。 |
| 识别模型 ID | "" | 最多200字符 | 可从 API 返回的模型列表选择；此处不能填写网址。 |
| 语言参数（可留空） | "" | 最多40字符 | 按页面提示设置；保存后用于之后的新任务。 |
| 上传音频格式 | "wav" | wav / silk | 新版宿主内置 SILK 转 WAV 组件，无需安装 Python 依赖或识别模型；silk 则直接上传原始音频。 |
| multipart 音频字段名 | "file" | 最多100字符 | 按页面提示设置；保存后用于之后的新任务。 |
| multipart 模型字段名 | "model" | 最多100字符 | 按页面提示设置；保存后用于之后的新任务。 |
| multipart 语言字段名 | "language" | 最多100字符 | 按页面提示设置；保存后用于之后的新任务。 |
| multipart 额外字段（JSON 对象） | "{}" | 最多16000字符 | 按页面提示设置；保存后用于之后的新任务。 |
| JSON 请求模板 | "{\"audio\":\"{{audio_base64}}\",\"model\":\"{{model}}\"}" | 最多32000字符 | 支持 {{audio_base64}}、{{audio_data_url}}、{{model}}、{{language}}、{{filename}}、{{mime_type}}、{{sample_rate}}、{{audio_bytes}}。 |
| 响应格式 | "json" | json / text | 按页面提示设置；保存后用于之后的新任务。 |
| JSON 转写结果路径 | "text" | 最多300字符 | 例如 text、data.text、results.0.text；留空表示根值。 |
| API 超时（毫秒） | 20000 | 1000–25000 | 按页面提示设置；保存后用于之后的新任务。 |
| 最长语音（秒） | 60 | 1–60 | 按页面提示设置；保存后用于之后的新任务。 |
| 转写文本长度上限 | 4000 | 100–4000 | 按页面提示设置；保存后用于之后的新任务。 |
| 缓存本进程内已识别的消息，避免重复上传 | true | 开 / 关 | 按页面提示设置；保存后用于之后的新任务。 |
| 模型列表 API 地址（可留空） | "" | 最多2048字符 | 留空时在识别接口同一服务下尝试常见 models 路径；特殊服务可填写完整 GET 地址。 |
| 模型列表 JSON 路径 | "data" | 最多300字符 | 通常为 data；也支持 models 或 data.models。 |
| 配置页自动读取模型列表（不自动测试语音） | true | 开 / 关 | 按页面提示设置；保存后用于之后的新任务。 |

## 限制与排查

开启后会把当前语音传给所选识别服务，可能消耗额度；不要把接口地址或模型名称猜成可用服务。

- 状态“已安装，尚未启用”：检查插件总开关、权限和聊天范围。
- 状态“等待新版宿主”：准备配置后从托盘完整重开DSH。
- 模型或本地环境报错：先在对应功能页做连接检测或本机试听，不要重复发送真实消息试错。
- 不要在公开问题报告中贴令牌、Cookie、聊天原文或私人路径。

## 来源与许可

随包保留的LICENSE、UPSTREAM及第三方声明继续有效；请同时阅读仓库[来源与许可](https://github.com/my12yyds/WeChatGirl/blob/main/LICENSES.md)。模型和运行环境不因插件ZIP可下载而自动具备，也不随总包分发。
